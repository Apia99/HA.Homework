//
//  Utils.swift
//  MovieApp
//
//  Created by Admin on 22/02/2022.
//

import Foundation

class Utils {
    static let keyName = "keyName"
}
