//
//  NetworkURL.swift
//  MovieApp
//
//  Created by Admin on 17/02/2022.
//

//import Foundation
//
//enum NetworkURL {
//    
//    static let baseMovieURL = "https://api.themoviedb.org/3/movie/popular?language=enUS&page=1&api_key=6622998c4ceac172a976a1136b204df4"
//}
